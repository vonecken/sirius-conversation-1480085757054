(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:tooltip'] = {};

})();
